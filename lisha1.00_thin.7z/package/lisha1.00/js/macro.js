function lisha_open_lmod(lisha_id)
{
	lisha_lmod_click(lisha_id);
}

function lisha_refresh(lisha_id)
{
	lisha_refresh_page_ajax(lisha_id);
}