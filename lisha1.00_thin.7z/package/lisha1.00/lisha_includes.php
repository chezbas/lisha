<?php
	require $path_root_lisha.'/includes/constant.php';
	require $path_root_lisha.'/class/lisha/db_engine/class_mysql.php';
	require $path_root_lisha.'/class/lisha/db_engine/class_postgresql.php';
	require $path_root_lisha.'/class/common/class_bdd.php';
	require $path_root_lisha.'/class/lisha/class_lisha.php';
	require $path_root_lisha.'/class/lisha/class_graphic.php';